﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HoyaCollege
{
    public partial class RegistorModule : Form
    {
        public RegistorModule()
        {
            InitializeComponent();
        }

        private void RegistorCourse_Load(object sender, EventArgs e)
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataHandler handler = new DataHandler();
            handler.Register(txtCode.Text, txtName.Text, cbxYear.Text, (int)nudCredit.Value, cbxType.Text, rtbDescription.Text);
        }
    }
}
