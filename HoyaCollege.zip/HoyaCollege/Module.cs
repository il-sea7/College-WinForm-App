﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoyaCollege
{
   public class Module
    {
        private string moduleCode, moduleName, year;
        private int credits;
        private string course, description;

        public Module(string moduleCode, string moduleName, string year, int credits, string course, string description)
        {
            this.moduleCode = moduleCode;
            this.moduleName = moduleName;
            this.year = year;
            this.credits = credits;
            this.course = course;
            this.description = description;
        }
        public Module() { }

        public string ModuleCode { get => moduleCode; set => moduleCode = value; }
        public string ModuleName { get => moduleName; set => moduleName = value; }
        public string Year { get => year; set => year = value; }
        public int Credits { get => credits; set => credits = value; }
        public string Course { get => course; set => course = value; }
        public string Description { get => description; set => description = value; }
    }
}
