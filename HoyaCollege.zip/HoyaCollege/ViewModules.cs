﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HoyaCollege
{
    public partial class ViewModules : Form
    {

        public BindingSource source = new BindingSource();
        public ViewModules()
        {
            InitializeComponent();
            DataHandler handler = new DataHandler();
            source =  handler.Select(dataGridView1);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            UpdateModule uf = new UpdateModule();
            this.Hide();
            uf.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            RegistorModule rf = new RegistorModule();
            this.Hide();
            rf.Show();
            
        }

        private void ViewCourse_Load(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            App af = new App();
            this.Hide();
            af.Show();
        }
        
        
        
        private void button1_Click(object sender, EventArgs e)
        {
            source.MoveFirst();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            source.MovePrevious();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            source.MoveNext();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            source.MoveLast();
        }
    }
}
