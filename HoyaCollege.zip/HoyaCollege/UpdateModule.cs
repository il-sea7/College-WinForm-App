﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HoyaCollege
{
    public partial class UpdateModule : Form
    {
        public UpdateModule()
        {
            InitializeComponent();
        }
        DataHandler handler = new DataHandler();
        List<Module> modules = new List<Module>();
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchID = txtSearch.Text;
            modules = handler.Search(searchID);

            foreach (var item in modules)
            {
                txtCode.Text = item.ModuleCode;
                txtName.Text = item.ModuleName;
                cbxYear.Text = item.Year;
                nudCredit.Value = item.Credits;
                cbxType.Text = item.Course;
                rtbDescription.Text = item.Description;
            }                        
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            handler.Update(txtCode.Text, txtName.Text, cbxYear.Text, (int)nudCredit.Value, cbxType.Text, rtbDescription.Text);
        }
    }
}
