﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HoyaCollege
{
    class DataHandler
    {
        public DataHandler() { }

        string connect = @"Server=.; Initial Catalog= HoyaCollegeDB; Integrated Security=SSPI";
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader reader;

        public BindingSource source = new BindingSource();
        public Module module = new Module();
        public void Register(string moduleCode, string moduleName, string year, int credits, string course, string description)
        {
            string query = @"INSERT INTO Module VALUES('" + moduleCode + "', '" + moduleName + "','" + year + "','" + credits + "','" + course + "','" + description + "')";

            conn = new SqlConnection(connect);
            conn.Open();

            cmd = new SqlCommand(query, conn);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Module inserted");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Details of module not saved: {0}", ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        public BindingSource Select(DataGridView dgv)
        {
            string connect = @"Data Source = (local); Initial Catalog = HoyaCollegeDB; Integrated Security = SSPI";
            SqlConnection conn = new SqlConnection(connect);
           

            string query = @"SELECT * FROM Module";

            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);

            DataTable table = new DataTable();
            adapter.Fill(table);
            source.DataSource = table;
            dgv.DataSource = source;
            return source;
        }

        public List<Module> Search(string moduleCode)
        {
             
            string query = @"SELECT * FROM Module WHERE ModuleCode = ('" + moduleCode + "')";
            conn = new SqlConnection(connect);
            conn.Open();

            cmd = new SqlCommand(query, conn);

            List<Module> myModule = new List<Module>();

            try
            {
                reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    module.ModuleCode= reader[0].ToString();
                    module.ModuleName = reader[1].ToString();
                    module.Year = reader[2].ToString();
                    module.Credits = int.Parse(reader[3].ToString());
                    module.Course = reader[4].ToString();
                    module.Description = reader[5].ToString();


                    myModule.Add(new Module(module.ModuleCode, module.ModuleName, module.Year, module.Credits, module.Course, module.Description));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Details of Module not searched: {0}", ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return myModule;
        }

        public void Update(string moduleCode, string moduleName, string year, int credits, string course, string description)
        {
            string query = @"UPDATE Module SET ModuleCode = ('" + moduleCode + "'), ModuleName =('" + moduleName + "'), Year=('" + year + "'), Credit=('" + credits + "'), Course=('" + course + "'), Description=('" + description + "') WHERE ModuleCode = ('" + moduleCode + "')";

            conn = new SqlConnection(connect);
            conn.Open();

            cmd = new SqlCommand(query, conn);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Module updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Details of module not updated: {0}", ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}

