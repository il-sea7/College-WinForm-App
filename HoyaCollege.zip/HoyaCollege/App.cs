﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HoyaCollege
{
    public partial class App : Form
    {
        public App()
        {
            InitializeComponent();
        }

        private void btnRegisterModules_Click(object sender, EventArgs e)
        {
            RegistorModule rf = new RegistorModule();
            rf.Show();
        }

        private void btnViewModules_Click(object sender, EventArgs e)
        {
            ViewModules vf = new ViewModules();
            vf.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateModule uf = new UpdateModule();
            uf.Show();
        }

        private void App_Load(object sender, EventArgs e)
        {
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
